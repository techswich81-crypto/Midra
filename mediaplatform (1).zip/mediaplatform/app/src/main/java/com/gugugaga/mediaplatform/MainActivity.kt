package com.gugugaga.mediaplatform

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.gugugaga.mediaplatform.browser.TabManager
import com.gugugaga.mediaplatform.data.AppPrefs
import com.gugugaga.mediaplatform.ui.AppRoot
import com.gugugaga.mediaplatform.ui.extras.LockScreen
import com.gugugaga.mediaplatform.ui.theme.MediaTheme
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    @Inject lateinit var prefs: AppPrefs
    @Inject lateinit var tabManager: TabManager

    private var locked by mutableStateOf(false)
    private var stoppedAt = 0L

    /** Per-app language from our own setting (no AppCompat dependency). */
    override fun attachBaseContext(newBase: Context) {
        val lang = newBase.getSharedPreferences("mp_prefs", MODE_PRIVATE).getString("lang", "system") ?: "system"
        if (lang == "system") { super.attachBaseContext(newBase); return }
        val loc = Locale(lang)
        Locale.setDefault(loc)
        val cfg = Configuration(newBase.resources.configuration)
        cfg.setLocale(loc)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            val mode by prefs.themeMode.collectAsState()
            val accent by prefs.accentFlow.collectAsState()
            val dynamic by prefs.dynamicFlow.collectAsState()
            MediaTheme(mode, accent, dynamic) {
                Box {
                    AppRoot()
                    if (locked) LockScreen(onUnlock = { authenticate() })
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (prefs.appLock && (stoppedAt == 0L || System.currentTimeMillis() - stoppedAt > 30_000)) {
            locked = true
            authenticate()
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = System.currentTimeMillis()
    }

    private fun authenticate() {
        val auth = if (Build.VERSION.SDK_INT >= 30)
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        else BiometricManager.Authenticators.BIOMETRIC_WEAK
        // No biometrics / screen lock configured -> never trap the user outside the app.
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            locked = false
            return
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("App unlock")
            .setAllowedAuthenticators(auth)
            .apply { if (Build.VERSION.SDK_INT < 30) setNegativeButtonText("Cancel") }
            .build()
        BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { locked = false }
            },
        ).authenticate(info)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** VIEW/SEND -> new tab; shortcut + widget actions -> screens. */
    private fun handleIntent(i: Intent?) {
        when (i?.action) {
            ACTION_SEARCH -> { tabManager.navTarget = "search"; return }
            ACTION_TABS -> { tabManager.navTarget = "mytabs"; return }
            ACTION_LAST -> {
                val u = prefs.lastUrl
                if (u.startsWith("http")) { tabManager.open(u, prefs.lastTitle); tabManager.navRequest++ }
                return
            }
        }
        val url = when (i?.action) {
            Intent.ACTION_VIEW -> i?.dataString
            Intent.ACTION_SEND -> i?.getStringExtra(Intent.EXTRA_TEXT)?.let { Regex("https?://\\S+").find(it)?.value }
            else -> null
        } ?: return
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) return
        tabManager.open(url)
        tabManager.navRequest++
    }

    /** Fullscreen video + Home button -> Picture-in-Picture. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && tabManager.customView != null) {
            runCatching {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            }
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= 10) tabManager.trim() // RUNNING_LOW or worse: suspend background tabs
    }

    companion object {
        const val ACTION_SEARCH = "com.gugugaga.mediaplatform.OPEN_SEARCH"
        const val ACTION_TABS = "com.gugugaga.mediaplatform.OPEN_MYTABS"
        const val ACTION_LAST = "com.gugugaga.mediaplatform.OPEN_LAST"
    }
}

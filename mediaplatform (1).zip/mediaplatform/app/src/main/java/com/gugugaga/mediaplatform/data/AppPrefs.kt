package com.gugugaga.mediaplatform.data

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppPrefs @Inject constructor(@ApplicationContext ctx: Context) {
    private val sp = ctx.getSharedPreferences("mp_prefs", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(sp.getString("theme", "system") ?: "system")
    val themeMode: StateFlow<String> = _theme.asStateFlow()
    fun setTheme(mode: String) {
        sp.edit().putString("theme", mode).apply()
        _theme.value = mode
    }

    var syncedVersion: Long
        get() = sp.getLong("synced_version", -1L)
        set(v) { sp.edit().putLong("synced_version", v).apply() }

    var serverOffset: Long
        get() = sp.getLong("server_offset", 0L)
        set(v) { sp.edit().putLong("server_offset", v).apply() }

    var historyAutoClearDays: Int
        get() = sp.getInt("history_days", 0)
        set(v) { sp.edit().putInt("history_days", v).apply() }

    var lastUrl: String
        get() = sp.getString("last_url", "") ?: ""
        set(v) { sp.edit().putString("last_url", v).apply() }

    var lastTitle: String
        get() = sp.getString("last_title", "") ?: ""
        set(v) { sp.edit().putString("last_title", v).apply() }

    fun recentSearches(): List<String> =
        (sp.getString("recent_searches", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun addRecentSearch(q: String) {
        val t = q.trim().replace("\n", " ")
        if (t.isEmpty()) return
        val list = (listOf(t) + recentSearches().filter { !it.equals(t, true) }).take(10)
        sp.edit().putString("recent_searches", list.joinToString("\n")).apply()
    }

    fun clearRecentSearches() { sp.edit().remove("recent_searches").apply() }

    /** Client-side rate limit: count at most one open per site per day. */
    fun shouldCountClick(siteId: String): Boolean {
        val key = "click_$siteId"
        val today = System.currentTimeMillis() / 86_400_000L
        if (sp.getLong(key, -1L) == today) return false
        sp.edit().putLong(key, today).apply()
        return true
    }

    // ---- Drop 2: browser + ad-block settings ----
    var adblockMode: String
        get() = sp.getString("adblock_mode", "normal") ?: "normal"
        set(v) { sp.edit().putString("adblock_mode", v).apply() }

    var adblockKill: Boolean
        get() = sp.getBoolean("adblock_kill", false)
        set(v) { sp.edit().putBoolean("adblock_kill", v).apply() }

    var adblockUpdatedAt: Long
        get() = sp.getLong("adblock_updated_at", 0L)
        set(v) { sp.edit().putLong("adblock_updated_at", v).apply() }

    var adblockEtag: String
        get() = sp.getString("adblock_etag", "") ?: ""
        set(v) { sp.edit().putString("adblock_etag", v).apply() }

    var stripTracking: Boolean
        get() = sp.getBoolean("strip_tracking", true)
        set(v) { sp.edit().putBoolean("strip_tracking", v).apply() }

    var httpsUpgrade: Boolean
        get() = sp.getBoolean("https_upgrade", true)
        set(v) { sp.edit().putBoolean("https_upgrade", v).apply() }

    var thirdPartyCookies: Boolean
        get() = sp.getBoolean("third_party_cookies", true)
        set(v) { sp.edit().putBoolean("third_party_cookies", v).apply() }

    var savedTabs: String
        get() = sp.getString("saved_tabs", "") ?: ""
        set(v) { sp.edit().putString("saved_tabs", v).apply() }

    fun siteSetting(host: String, key: String): String? = sp.getString("site_${host}_$key", null)

    fun setSiteSetting(host: String, key: String, value: String?) {
        val k = "site_${host}_$key"
        if (value == null) sp.edit().remove(k).apply() else sp.edit().putString(k, value).apply()
    }

    var announcement: String
        get() = sp.getString("announcement", "") ?: ""
        set(v) { sp.edit().putString("announcement", v).apply() }

    var adminFails: Int
        get() = sp.getInt("admin_fails", 0)
        set(v) { sp.edit().putInt("admin_fails", v).apply() }

    var adminLockUntil: Long
        get() = sp.getLong("admin_lock_until", 0L)
        set(v) { sp.edit().putLong("admin_lock_until", v).apply() }

    // ---- Drop 3+ ----
    private val _accent = MutableStateFlow(sp.getString("accent", "blue") ?: "blue")
    val accentFlow: StateFlow<String> = _accent.asStateFlow()
    fun setAccent(v: String) { sp.edit().putString("accent", v).apply(); _accent.value = v }

    private val _dynamic = MutableStateFlow(sp.getBoolean("dynamic_color", true))
    val dynamicFlow: StateFlow<Boolean> = _dynamic.asStateFlow()
    fun setDynamic(v: Boolean) { sp.edit().putBoolean("dynamic_color", v).apply(); _dynamic.value = v }

    var trending: String
        get() = sp.getString("trending", "") ?: ""
        set(v) { sp.edit().putString("trending", v).apply() }

    var learnedIndex: Boolean
        get() = sp.getBoolean("learned_index", true)
        set(v) { sp.edit().putBoolean("learned_index", v).apply() }

    var dataSaver: Boolean
        get() = sp.getBoolean("data_saver", false)
        set(v) { sp.edit().putBoolean("data_saver", v).apply() }

    var appLock: Boolean
        get() = sp.getBoolean("app_lock", false)
        set(v) { sp.edit().putBoolean("app_lock", v).apply() }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    var lang: String
        get() = sp.getString("lang", "system") ?: "system"
        set(v) { sp.edit().putString("lang", v).apply() }

    var notifAll: Boolean
        get() = sp.getBoolean("notif_all", false)
        set(v) { sp.edit().putBoolean("notif_all", v).apply() }

    var notifNews: Boolean
        get() = sp.getBoolean("notif_news", false)
        set(v) { sp.edit().putBoolean("notif_news", v).apply() }

    /** "host:camera" style entries the user chose "Always allow" for. */
    fun allowedPerms(): List<String> =
        (sp.getString("perm_allowed", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun addAllowedPerm(entry: String) {
        sp.edit().putString("perm_allowed", (allowedPerms() + entry).distinct().joinToString("\n")).apply()
    }

    fun removeAllowedPerm(entry: String) {
        sp.edit().putString("perm_allowed", allowedPerms().filter { it != entry }.joinToString("\n")).apply()
    }

    fun downloadIds(): List<Long> =
        (sp.getString("download_ids", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }

    fun addDownloadId(id: Long) {
        sp.edit().putString("download_ids", (listOf(id) + downloadIds()).take(100).joinToString(",")).apply()
    }

    var hideCookieBanners: Boolean
        get() = sp.getBoolean("hide_cookie_banners", false)
        set(v) { sp.edit().putBoolean("hide_cookie_banners", v).apply() }

    var crashReports: Boolean
        get() = sp.getBoolean("crash_reports", true)
        set(v) { sp.edit().putBoolean("crash_reports", v).apply() }

    var digest: Boolean
        get() = sp.getBoolean("digest", false)
        set(v) { sp.edit().putBoolean("digest", v).apply() }

    var safeMode: Boolean
        get() = sp.getBoolean("safe_mode", false)
        set(v) { sp.edit().putBoolean("safe_mode", v).apply() }

    var safePinHash: String
        get() = sp.getString("safe_pin_hash", "") ?: ""
        set(v) { sp.edit().putString("safe_pin_hash", v).apply() }

    var maintenanceMsg: String
        get() = sp.getString("maintenance_msg", "") ?: ""
        set(v) { sp.edit().putString("maintenance_msg", v).apply() }

    var minVersion: String
        get() = sp.getString("min_version", "") ?: ""
        set(v) { sp.edit().putString("min_version", v).apply() }
}

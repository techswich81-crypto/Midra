package com.gugugaga.mediaplatform.data

import com.gugugaga.mediaplatform.data.local.BookmarkDao
import com.gugugaga.mediaplatform.data.local.BookmarkEntity
import com.gugugaga.mediaplatform.data.local.CartDao
import com.gugugaga.mediaplatform.data.local.CartItem
import com.gugugaga.mediaplatform.data.local.FavoriteDao
import com.gugugaga.mediaplatform.data.local.FavoriteEntity
import com.gugugaga.mediaplatform.data.local.MyTabDao
import com.gugugaga.mediaplatform.data.local.MyTabEntity
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/** Local backup (no account): cart, My Tabs, bookmarks, favorites <-> JSON. */
@Singleton
class BackupManager @Inject constructor(
    private val cart: CartDao,
    private val tabs: MyTabDao,
    private val bookmarks: BookmarkDao,
    private val favorites: FavoriteDao,
) {
    suspend fun exportJson(): String {
        val o = JSONObject()
        o.put("version", 1)
        o.put("cart", JSONArray().also { a ->
            cart.all().forEach { a.put(JSONObject().put("title", it.title).put("url", it.url).put("note", it.note).put("folder", it.folder).put("addedAt", it.addedAt)) }
        })
        o.put("myTabs", JSONArray().also { a ->
            tabs.all().forEach { a.put(JSONObject().put("name", it.name).put("url", it.url).put("folder", it.folder).put("createdAt", it.createdAt)) }
        })
        o.put("bookmarks", JSONArray().also { a ->
            bookmarks.all().forEach { a.put(JSONObject().put("title", it.title).put("url", it.url).put("folder", it.folder).put("createdAt", it.createdAt)) }
        })
        o.put("favorites", JSONArray().also { a -> favorites.allIds().forEach { a.put(it) } })
        return o.toString(2)
    }

    /** Returns number of imported items. */
    suspend fun importJson(json: String): Int {
        val o = JSONObject(json)
        var n = 0
        o.optJSONArray("cart")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                cart.insert(CartItem(title = x.optString("title"), url = x.getString("url"), note = x.optString("note"), folder = x.optString("folder"), addedAt = x.optLong("addedAt", System.currentTimeMillis())))
                n++
            }
        }
        o.optJSONArray("myTabs")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                tabs.insert(MyTabEntity(name = x.optString("name"), url = x.getString("url"), folder = x.optString("folder"), createdAt = x.optLong("createdAt", System.currentTimeMillis())))
                n++
            }
        }
        o.optJSONArray("bookmarks")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.getJSONObject(i)
                bookmarks.insert(BookmarkEntity(title = x.optString("title"), url = x.getString("url"), folder = x.optString("folder"), createdAt = x.optLong("createdAt", System.currentTimeMillis())))
                n++
            }
        }
        o.optJSONArray("favorites")?.let { a ->
            for (i in 0 until a.length()) { favorites.insert(FavoriteEntity(a.getString(i))); n++ }
        }
        return n
    }
}

package com.gugugaga.mediaplatform.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        SiteEntity::class, CategoryEntity::class, CartItem::class, MyTabEntity::class,
        HistoryEntity::class, BookmarkEntity::class, FavoriteEntity::class, LearnedPage::class,
    ],
    version = 3,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun siteDao(): SiteDao
    abstract fun categoryDao(): CategoryDao
    abstract fun cartDao(): CartDao
    abstract fun myTabDao(): MyTabDao
    abstract fun historyDao(): HistoryDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun learnedDao(): LearnedDao
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE cart ADD COLUMN offlinePath TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE sites ADD COLUMN searchUrlPattern TEXT NOT NULL DEFAULT ''")
        db.execSQL("CREATE TABLE IF NOT EXISTS learned_pages (url TEXT NOT NULL, title TEXT NOT NULL, headings TEXT NOT NULL, body TEXT NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(url))")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE cart ADD COLUMN folder TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE my_tabs ADD COLUMN position INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE my_tabs ADD COLUMN folder TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE bookmarks ADD COLUMN folder TEXT NOT NULL DEFAULT ''")
    }
}

package com.gugugaga.mediaplatform.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class SiteDao {
    @Query("SELECT * FROM sites WHERE active = 1")
    abstract fun observeActive(): Flow<List<SiteEntity>>

    @Query("SELECT * FROM sites WHERE active = 1")
    abstract suspend fun getActive(): List<SiteEntity>

    @Query("SELECT COUNT(*) FROM sites")
    abstract suspend fun count(): Int

    @Query("DELETE FROM sites")
    abstract suspend fun clear()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertAll(items: List<SiteEntity>)

    @Transaction
    open suspend fun replaceAll(items: List<SiteEntity>) {
        clear()
        insertAll(items)
    }
}

@Dao
abstract class CategoryDao {
    @Query("SELECT * FROM categories WHERE active = 1 ORDER BY sortOrder ASC")
    abstract fun observeActive(): Flow<List<CategoryEntity>>

    @Query("DELETE FROM categories")
    abstract suspend fun clear()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertAll(items: List<CategoryEntity>)

    @Transaction
    open suspend fun replaceAll(items: List<CategoryEntity>) {
        clear()
        insertAll(items)
    }
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart ORDER BY addedAt DESC")
    fun observe(): Flow<List<CartItem>>

    @Query("SELECT * FROM cart")
    suspend fun all(): List<CartItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CartItem): Long

    @Query("DELETE FROM cart WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM cart WHERE title LIKE '%' || :q || '%' OR url LIKE '%' || :q || '%' LIMIT 20")
    suspend fun search(q: String): List<CartItem>
}

@Dao
interface MyTabDao {
    @Query("SELECT * FROM my_tabs ORDER BY position ASC, createdAt DESC")
    fun observe(): Flow<List<MyTabEntity>>

    @Query("SELECT * FROM my_tabs")
    suspend fun all(): List<MyTabEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: MyTabEntity): Long

    @Query("DELETE FROM my_tabs WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM my_tabs WHERE name LIKE '%' || :q || '%' OR url LIKE '%' || :q || '%' LIMIT 20")
    suspend fun search(q: String): List<MyTabEntity>
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY visitedAt DESC LIMIT 500")
    fun observeAll(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE id IN (SELECT MAX(id) FROM history GROUP BY url) ORDER BY visitedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<HistoryEntity>>

    @Insert
    suspend fun insert(item: HistoryEntity): Long

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM history")
    suspend fun clear()

    @Query("DELETE FROM history WHERE visitedAt < :ts")
    suspend fun deleteOlderThan(ts: Long)

    @Query("SELECT * FROM history WHERE id IN (SELECT MAX(id) FROM history WHERE title LIKE '%' || :q || '%' OR url LIKE '%' || :q || '%' GROUP BY url) ORDER BY visitedAt DESC LIMIT 20")
    suspend fun search(q: String): List<HistoryEntity>
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun observe(): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks")
    suspend fun all(): List<BookmarkEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: BookmarkEntity): Long

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteByUrl(url: String)

    @Query("SELECT COUNT(*) FROM bookmarks WHERE url = :url")
    fun countByUrl(url: String): Flow<Int>

    @Query("SELECT * FROM bookmarks WHERE title LIKE '%' || :q || '%' OR url LIKE '%' || :q || '%' LIMIT 20")
    suspend fun search(q: String): List<BookmarkEntity>
}

@Dao
interface FavoriteDao {
    @Query("SELECT siteId FROM favorites")
    fun observeIds(): Flow<List<String>>

    @Query("SELECT siteId FROM favorites")
    suspend fun allIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE siteId = :siteId")
    suspend fun delete(siteId: String)
}

@Dao
interface LearnedDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: LearnedPage)

    @Query("SELECT * FROM learned_pages WHERE title LIKE '%' || :q || '%' OR headings LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' ORDER BY updatedAt DESC LIMIT 20")
    suspend fun search(q: String): List<LearnedPage>

    @Query("DELETE FROM learned_pages WHERE url NOT IN (SELECT url FROM learned_pages ORDER BY updatedAt DESC LIMIT 1000)")
    suspend fun prune()

    @Query("DELETE FROM learned_pages")
    suspend fun clear()
}

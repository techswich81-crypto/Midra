package com.gugugaga.mediaplatform.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "sites")
data class SiteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val iconUrl: String = "",
    val category: String = "",
    val tags: String = "",
    val description: String = "",
    val active: Boolean = true,
    val featured: Boolean = false,
    val isHot: Boolean = false,
    val priorityScore: Int = 0,
    val isPinned: Boolean = false,
    val hotUntil: Long = 0,
    val rankOrder: Int = 0,
    val clickCount: Long = 0,
    val adBlockMode: String = "normal",
    val browsingMode: String = "webview",
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    @ColumnInfo(defaultValue = "''") val searchUrlPattern: String = "",
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val icon: String = "",
    val sortOrder: Int = 0,
    val active: Boolean = true,
)

@Entity(tableName = "cart", indices = [Index(value = ["url"], unique = true)])
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val note: String = "",
    val addedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "''") val offlinePath: String = "",
    @ColumnInfo(defaultValue = "''") val folder: String = "",
)

@Entity(tableName = "my_tabs", indices = [Index(value = ["url"], unique = true)])
data class MyTabEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val url: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val position: Int = 0,
    @ColumnInfo(defaultValue = "''") val folder: String = "",
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val visitedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "bookmarks", indices = [Index(value = ["url"], unique = true)])
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "''") val folder: String = "",
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val siteId: String)

@Entity(tableName = "learned_pages")
data class LearnedPage(
    @PrimaryKey val url: String,
    val title: String,
    val headings: String,
    val body: String,
    val updatedAt: Long = System.currentTimeMillis(),
)

package com.gugugaga.mediaplatform.data.remote

import com.gugugaga.mediaplatform.data.AppPrefs
import com.gugugaga.mediaplatform.data.local.CategoryDao
import com.gugugaga.mediaplatform.data.local.CategoryEntity
import com.gugugaga.mediaplatform.data.local.SiteDao
import com.gugugaga.mediaplatform.data.local.SiteEntity
import com.gugugaga.mediaplatform.util.Util
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SiteRepository @Inject constructor(
    private val db: FirebaseDatabase,
    private val siteDao: SiteDao,
    private val categoryDao: CategoryDao,
    private val prefs: AppPrefs,
) {
    fun nowServer(): Long = System.currentTimeMillis() + prefs.serverOffset

    /**
     * One-shot sync (no permanent listener -> saves RTDB connections).
     * Checks the tiny config/version node first; full fetch only when changed.
     */
    suspend fun sync(force: Boolean = false): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            runCatching {
                withTimeout(8_000) {
                    val off = db.getReference(".info/serverTimeOffset").get().await().value
                    (off as? Number)?.let { prefs.serverOffset = it.toLong() }
                }
            }
            val remoteVersion = withTimeout(15_000) {
                (db.reference.child("config/version").get().await().value as? Number)?.toLong() ?: 0L
            }
            val unchanged = remoteVersion != 0L && remoteVersion == prefs.syncedVersion
            if (!force && unchanged && siteDao.count() > 0) return@runCatching

            val sitesSnap = withTimeout(25_000) { db.reference.child("websites").get().await() }
            val catSnap = withTimeout(25_000) { db.reference.child("categories").get().await() }
            siteDao.replaceAll(parseSites(sitesSnap))
            categoryDao.replaceAll(parseCategories(catSnap))
            runCatching {
                prefs.announcement = withTimeout(8_000) {
                    db.reference.child("config/announcement").get().await().value?.toString().orEmpty()
                }
            }
            runCatching {
                prefs.maintenanceMsg = withTimeout(8_000) {
                    db.reference.child("config/maintenance").get().await().value?.toString().orEmpty()
                }
            }
            runCatching {
                val t = withTimeout(8_000) { db.reference.child("config/trendingSearches").get().await() }
                prefs.trending = when (val v = t.value) {
                    is List<*> -> v.filterNotNull().joinToString(",")
                    null -> ""
                    else -> v.toString()
                }
            }
            prefs.syncedVersion = remoteVersion
        }
    }

    /** Public counter: +1 only, max once per site per day per device. */
    fun recordOpen(siteId: String) {
        if (!prefs.shouldCountClick(siteId)) return
        runCatching {
            db.getReference("websites/$siteId/clickCount").setValue(ServerValue.increment(1))
        }
    }

    private fun DataSnapshot.text(k: String): String = when (val v = child(k).value) {
        null -> ""
        is List<*> -> v.filterNotNull().joinToString(",")
        is Map<*, *> -> v.values.joinToString(",")
        else -> v.toString()
    }

    private fun DataSnapshot.bool(k: String, d: Boolean): Boolean = (child(k).value as? Boolean) ?: d
    private fun DataSnapshot.num(k: String): Long = (child(k).value as? Number)?.toLong() ?: 0L

    private fun parseSites(snap: DataSnapshot): List<SiteEntity> = snap.children.mapNotNull { c ->
        val id = c.key ?: return@mapNotNull null
        val url = c.text("url").trim()
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) return@mapNotNull null
        SiteEntity(
            id = id,
            name = c.text("name").ifBlank { Util.hostOf(url) },
            url = url,
            iconUrl = c.text("iconUrl"),
            category = c.text("category"),
            tags = c.text("tags"),
            description = c.text("description"),
            active = c.bool("active", true),
            featured = c.bool("featured", false),
            isHot = c.bool("isHot", false),
            priorityScore = c.num("priorityScore").toInt(),
            isPinned = c.bool("isPinned", false),
            hotUntil = c.num("hotUntil"),
            rankOrder = c.num("rankOrder").toInt(),
            clickCount = c.num("clickCount"),
            adBlockMode = c.text("adBlockMode").ifBlank { "normal" },
            browsingMode = c.text("browsingMode").ifBlank { "webview" },
            createdAt = c.num("createdAt"),
            updatedAt = c.num("updatedAt"),
            searchUrlPattern = c.text("searchUrlPattern"),
        )
    }

    private fun parseCategories(snap: DataSnapshot): List<CategoryEntity> = snap.children.mapNotNull { c ->
        val id = c.key ?: return@mapNotNull null
        CategoryEntity(
            id = id,
            name = c.text("name").ifBlank { id },
            icon = c.text("icon"),
            sortOrder = c.num("order").toInt(),
            active = c.bool("active", true),
        )
    }
}

package com.gugugaga.mediaplatform.di

import android.content.Context
import androidx.room.Room
import com.gugugaga.mediaplatform.data.local.AppDatabase
import com.gugugaga.mediaplatform.data.local.MIGRATION_1_2
import com.gugugaga.mediaplatform.data.local.MIGRATION_2_3
import com.google.firebase.database.FirebaseDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun database(@ApplicationContext c: Context): AppDatabase =
        Room.databaseBuilder(c, AppDatabase::class.java, "mediaplatform.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
            .fallbackToDestructiveMigration() // dev only: replace with real migrations before release
            .build()

    @Provides @Singleton
    fun firebase(): FirebaseDatabase = FirebaseDatabase.getInstance()

    @Provides fun siteDao(db: AppDatabase) = db.siteDao()
    @Provides fun categoryDao(db: AppDatabase) = db.categoryDao()
    @Provides fun cartDao(db: AppDatabase) = db.cartDao()
    @Provides fun myTabDao(db: AppDatabase) = db.myTabDao()
    @Provides fun historyDao(db: AppDatabase) = db.historyDao()
    @Provides fun bookmarkDao(db: AppDatabase) = db.bookmarkDao()
    @Provides fun favoriteDao(db: AppDatabase) = db.favoriteDao()
    @Provides fun learnedDao(db: AppDatabase) = db.learnedDao()
}

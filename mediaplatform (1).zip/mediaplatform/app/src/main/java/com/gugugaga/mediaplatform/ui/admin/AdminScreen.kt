package com.gugugaga.mediaplatform.ui.admin

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gugugaga.mediaplatform.data.admin.AdblockCfg
import com.gugugaga.mediaplatform.data.admin.AdminCategory
import com.gugugaga.mediaplatform.data.admin.AdminSite
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(onExit: () -> Unit, vm: AdminViewModel = hiltViewModel()) {
    val loggedIn by vm.loggedIn.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.clearMessage() } }
    LaunchedEffect(Unit) { while (true) { vm.tick(); delay(1_000) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin") },
                navigationIcon = { IconButton(onClick = { vm.logout(); onExit() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Exit") } },
                actions = { if (loggedIn) TextButton(onClick = { vm.logout() }) { Text("Logout") } },
            )
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (!loggedIn) LoginPane(vm) else Panel(vm)
        }
    }
}

@Composable
private fun LoginPane(vm: AdminViewModel) {
    val act = androidx.compose.ui.platform.LocalContext.current as? androidx.fragment.app.FragmentActivity
    var code by remember { mutableStateOf("") }
    var keepCode by remember { mutableStateOf(false) }
    val lock by vm.lockMs.collectAsStateWithLifecycle()
    val saved by vm.hasSaved.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Admin login", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Code wahi hai jo Firebase Console me admin user ka password banaya tha.",
            Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = code, onValueChange = { code = it }, singleLine = true, label = { Text("Admin code") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(checked = keepCode, onCheckedChange = { keepCode = it })
            Text("Is device par code yaad rakho (encrypted, fingerprint se khulega)", style = MaterialTheme.typography.bodySmall)
        }
        if (lock > 0) Text("Locked: ${lock / 1000}s", color = MaterialTheme.colorScheme.error)
        Button(onClick = { vm.login(code, keepCode); code = "" }, enabled = lock <= 0 && code.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Login") }
        if (saved) {
            androidx.compose.material3.OutlinedButton(
                onClick = {
                    if (act != null) com.gugugaga.mediaplatform.util.confirmDeviceOwner(act, "Admin unlock") { vm.loginSaved() } else vm.loginSaved()
                },
                enabled = lock <= 0,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("Saved code se login") }
            TextButton(onClick = { vm.forgetSaved() }) { Text("Saved code bhool jao") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Panel(vm: AdminViewModel) {
    val titles = listOf("Dashboard", "Sites", "Categories", "Ad-block", "Announcement", "Reports", "Log")
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab) { vm.load(tab) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        when (tab) {
            0 -> DashboardTab(vm)
            1 -> SitesTab(vm)
            2 -> CategoriesTab(vm)
            3 -> AdblockTab(vm)
            4 -> AnnouncementTab(vm)
            5 -> ReportsTab(vm)
            else -> LogTab(vm)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SitesTab(vm: AdminViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val sites by vm.sites.collectAsStateWithLifecycle()
    val cats by vm.cats.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<AdminSite?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<AdminSite?>(null) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var bulkCategory by remember { mutableStateOf<String?>(null) }
    var bulkDelete by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val selecting = selected.isNotEmpty()

    val exportLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri != null) vm.exportSites { text ->
            runCatching { ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray()) } }
        }
    }
    val importLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) runCatching {
            val text = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
            vm.importSites(text)
        }
    }

    val shown = sites.filter { query.isBlank() || it.name.contains(query, true) || it.url.contains(query, true) || it.category.contains(query, true) }

    Column(Modifier.fillMaxSize()) {
        if (selecting) {
            Text("${selected.size} selected", Modifier.padding(start = 12.dp, top = 8.dp), style = MaterialTheme.typography.titleSmall)
            androidx.compose.foundation.lazy.LazyRow(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { TextButton(onClick = { vm.bulk(selected.toList(), "hot_on"); selected = emptySet() }) { Text("Hot ON") } }
                item { TextButton(onClick = { vm.bulk(selected.toList(), "hot_off"); selected = emptySet() }) { Text("Hot OFF") } }
                item { TextButton(onClick = { vm.bulk(selected.toList(), "pin_on"); selected = emptySet() }) { Text("Pin") } }
                item { TextButton(onClick = { vm.bulk(selected.toList(), "pin_off"); selected = emptySet() }) { Text("Unpin") } }
                item { TextButton(onClick = { vm.bulk(selected.toList(), "active_on"); selected = emptySet() }) { Text("Active") } }
                item { TextButton(onClick = { vm.bulk(selected.toList(), "active_off"); selected = emptySet() }) { Text("Suspend") } }
                item { TextButton(onClick = { vm.moveRank(selected.toList(), true); selected = emptySet() }) { Text("Top") } }
                item { TextButton(onClick = { vm.moveRank(selected.toList(), false); selected = emptySet() }) { Text("Bottom") } }
                item { TextButton(onClick = { bulkCategory = "" }) { Text("Category") } }
                item { TextButton(onClick = { bulkDelete = true }) { Text("Delete") } }
                item { TextButton(onClick = { selected = emptySet() }) { Text("Cancel") } }
            }
        } else {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("${sites.size} sites - filter") }, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.load(1) }) { Icon(Icons.Filled.Refresh, "Refresh") }
                IconButton(onClick = { creating = true }) { Icon(Icons.Filled.Add, "Add site") }
            }
            Row(Modifier.padding(horizontal = 8.dp)) {
                TextButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }) { Text("Import CSV/JSON") }
                TextButton(onClick = { exportLauncher.launch("sites-export.json") }) { Text("Export") }
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.id }) { s ->
                val sel = s.id in selected
                ListItem(
                    headlineContent = {
                        Text(
                            (if (sel) "✓ " else "") + s.name + (if (s.isPinned) "  [Pin]" else "") + (if (s.isHot) "  [Hot]" else "") + (if (!s.active) "  [OFF]" else ""),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    },
                    supportingContent = { Text("${s.url}\n${s.category} · score ${s.priorityScore} · rank ${s.rankOrder} · opens ${s.clickCount}", maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    trailingContent = { if (!selecting) IconButton(onClick = { deleting = s }) { Icon(Icons.Filled.Delete, "Delete") } },
                    modifier = Modifier.combinedClickable(
                        onClick = { if (selecting) selected = if (sel) selected - s.id else selected + s.id else editing = s },
                        onLongClick = { selected = selected + s.id },
                    ),
                )
            }
        }
    }

    if (creating || editing != null) {
        SiteDialog(
            site = editing,
            categories = cats,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.saveSite(it); creating = false; editing = null },
            onCheck = { u, cb -> vm.checkLink(u, cb) },
        )
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("'${s.name}' delete karein?") },
            confirmButton = { TextButton(onClick = { vm.deleteSite(s); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
    if (bulkDelete) {
        AlertDialog(
            onDismissRequest = { bulkDelete = false },
            title = { Text("${selected.size} sites delete karein?") },
            confirmButton = { TextButton(onClick = { vm.bulk(selected.toList(), "delete"); selected = emptySet(); bulkDelete = false }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { bulkDelete = false }) { Text("Cancel") } },
        )
    }
    bulkCategory?.let { c ->
        AlertDialog(
            onDismissRequest = { bulkCategory = null },
            title = { Text("Category badlo") },
            text = {
                Column {
                    OutlinedTextField(c, { bulkCategory = it }, label = { Text("Category") }, singleLine = true)
                    if (cats.isNotEmpty()) Text("Available: " + cats.joinToString { it.name }, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { vm.bulk(selected.toList(), "category", c); selected = emptySet(); bulkCategory = null }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { bulkCategory = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun DashboardTab(vm: AdminViewModel) {
    val sites by vm.sites.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val top = sites.sortedByDescending { it.clickCount }.take(10)
    val max = (top.firstOrNull()?.clickCount ?: 1L).coerceAtLeast(1L)
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(
                "Sites: ${sites.size} · Active: ${sites.count { it.active }} · Hot: ${sites.count { it.isHot }} · Pinned: ${sites.count { it.isPinned }}\nOpen reports: ${reports.size}",
                style = MaterialTheme.typography.titleSmall,
            )
            Text("Top 10 (opens, per device roughly 1/day)", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.labelLarge)
        }
        items(top, key = { it.id }) { s ->
            Column {
                Text("${s.name}  ·  ${s.clickCount}")
                LinearProgressIndicator(progress = { s.clickCount.toFloat() / max }, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            Text(
                "Trend arrows/daily-active/retention abhi nahi hain: iske liye server-side aggregation (Cloud Function, Blaze plan) chahiye.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun SiteDialog(site: AdminSite?, categories: List<AdminCategory>, onDismiss: () -> Unit, onSave: (AdminSite) -> Unit, onCheck: (String, (String) -> Unit) -> Unit) {
    val s0 = site ?: AdminSite()
    var name by remember { mutableStateOf(s0.name) }
    var url by remember { mutableStateOf(s0.url) }
    var icon by remember { mutableStateOf(s0.iconUrl) }
    var category by remember { mutableStateOf(s0.category) }
    var tags by remember { mutableStateOf(s0.tags) }
    var desc by remember { mutableStateOf(s0.description) }
    var active by remember { mutableStateOf(s0.active) }
    var featured by remember { mutableStateOf(s0.featured) }
    var hot by remember { mutableStateOf(s0.isHot) }
    var pinned by remember { mutableStateOf(s0.isPinned) }
    var score by remember { mutableFloatStateOf(s0.priorityScore.toFloat()) }
    var hotDays by remember { mutableStateOf("0") }
    var order by remember { mutableStateOf(s0.rankOrder.toString()) }
    var adMode by remember { mutableStateOf(s0.adBlockMode) }
    var browsing by remember { mutableStateOf(s0.browsingMode) }
    var searchPattern by remember { mutableStateOf(s0.searchUrlPattern) }
    var error by remember { mutableStateOf<String?>(null) }
    var linkResult by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (site == null) "Nayi site" else "Site edit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                F("Naam", name) { name = it }
                F("URL (https://...)", url) { url = it; linkResult = null }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { linkResult = "Check ho raha hai..."; onCheck(url) { linkResult = it } }) { Text("Link check") }
                    linkResult?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
                F("Icon URL (khaali = auto favicon)", icon) { icon = it }
                F("Category (naam ya id)", category) { category = it }
                if (categories.isNotEmpty()) Text("Categories: " + categories.joinToString { it.name }, style = MaterialTheme.typography.bodySmall)
                F("Tags / keywords (comma)", tags) { tags = it }
                F("Description", desc) { desc = it }
                F("Site search URL (QUERY jagah query): https://site.com/?s=QUERY", searchPattern) { searchPattern = it }
                Sw("Active", active) { active = it }
                Sw("Featured", featured) { featured = it }
                Sw("Hot", hot) { hot = it }
                Sw("Pinned (top)", pinned) { pinned = it }
                Text("Priority score: ${score.toInt()}")
                Slider(value = score, onValueChange = { score = it }, valueRange = 1f..100f)
                F("Hot kitne din (0 = hamesha)", hotDays) { hotDays = it.filter { c -> c.isDigit() }.take(3) }
                F("Rank order (chhota = pehle)", order) { order = it.filter { c -> c.isDigit() }.take(5) }
                Text("Ad-block mode")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("normal", "strict", "off").forEach { m -> FilterChip(selected = adMode == m, onClick = { adMode = m }, label = { Text(m) }) }
                }
                Text("Browsing mode")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("webview", "customtab").forEach { m -> FilterChip(selected = browsing == m, onClick = { browsing = m }, label = { Text(m) }) }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val u = url.trim()
                when {
                    name.isBlank() -> error = "Naam daalo"
                    !u.startsWith("http://", true) && !u.startsWith("https://", true) -> error = "URL http(s) se shuru ho"
                    else -> {
                        val days = hotDays.toIntOrNull() ?: 0
                        val until = if (hot && days > 0) System.currentTimeMillis() + days * 86_400_000L else 0L
                        onSave(
                            s0.copy(
                                name = name, url = u, iconUrl = icon, category = category, tags = tags, description = desc,
                                active = active, featured = featured, isHot = hot, isPinned = pinned,
                                priorityScore = score.toInt(), hotUntil = until, rankOrder = order.toIntOrNull() ?: 0,
                                adBlockMode = adMode, browsingMode = browsing, searchUrlPattern = searchPattern,
                            ),
                        )
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun CategoriesTab(vm: AdminViewModel) {
    val cats by vm.cats.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf("") }
    var order by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, label = { Text("Naam") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(
                order, { order = it.filter { c -> c.isDigit() }.take(3) }, label = { Text("Order") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(0.5f),
            )
            Button(onClick = { vm.addCategory(name, order.toIntOrNull() ?: 0); name = ""; order = "" }, enabled = name.isNotBlank()) { Text("Add") }
        }
        LazyColumn {
            items(cats, key = { it.id }) { c ->
                ListItem(
                    headlineContent = { Text(c.name) },
                    supportingContent = { Text("order ${c.order}") },
                    trailingContent = { IconButton(onClick = { vm.deleteCategory(c) }) { Icon(Icons.Filled.Delete, "Delete") } },
                )
            }
        }
    }
}

@Composable
private fun AdblockTab(vm: AdminViewModel) {
    val cfg by vm.adblock.collectAsStateWithLifecycle()
    var kill by remember(cfg) { mutableStateOf(cfg.kill) }
    var extra by remember(cfg) { mutableStateOf(cfg.extra) }
    var allow by remember(cfg) { mutableStateOf(cfg.allow) }
    var listUrl by remember(cfg) { mutableStateOf(cfg.listUrl) }
    var host by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Sw("Kill-switch: poora ad-block emergency OFF", kill) { kill = it }
        F("Filter list URL (https, hosts/ABP format)", listUrl) { listUrl = it }
        F("Extra blocked domains (comma)", extra) { extra = it }
        F("Allowlist domains (kabhi block nahi)", allow) { allow = it }
        Button(onClick = { vm.saveAdblock(AdblockCfg(kill, extra, allow, listUrl, cfg.cosmetic)) }) { Text("Save ad-block config") }
        Text("Clients ko update daily ya app start par milta hai.", style = MaterialTheme.typography.bodySmall)

        Text("Site-specific hide rules", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp))
        F("Host (example.com)", host) { host = it }
        F("CSS selectors (comma): .banner, #popup", sel) { sel = it }
        Button(onClick = { vm.saveCosmetic(host, sel); host = ""; sel = "" }, enabled = host.isNotBlank() && sel.isNotBlank()) { Text("Rule add") }
        cfg.cosmetic.forEach { (k, v) ->
            ListItem(
                headlineContent = { Text(k.replace('_', '.')) },
                supportingContent = { Text(v, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                trailingContent = { IconButton(onClick = { vm.deleteCosmetic(k) }) { Icon(Icons.Filled.Delete, "Delete") } },
            )
        }
    }
}

@Composable
private fun AnnouncementTab(vm: AdminViewModel) {
    val saved by vm.announcement.collectAsStateWithLifecycle()
    val maintSaved by vm.maintenance.collectAsStateWithLifecycle()
    var text by remember(saved) { mutableStateOf(saved) }
    var maint by remember(maintSaved) { mutableStateOf(maintSaved) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        F("Announcement (Home par dikhega; khaali = hatao)", text) { text = it.take(300) }
        Button(onClick = { vm.saveAnnouncement(text) }) { Text("Save announcement") }
        F("Maintenance message (khaali = maintenance band)", maint) { maint = it.take(200) }
        Button(onClick = { vm.saveMaintenance(maint) }) { Text("Save maintenance") }
    }
}

@Composable
private fun ReportsTab(vm: AdminViewModel) {
    val list by vm.reports.collectAsStateWithLifecycle()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    if (list.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Koi report nahi") }
    else LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.id }) { r ->
            ListItem(
                overlineContent = { Text(r.type + " · " + fmt.format(Date(r.ts))) },
                headlineContent = { Text(r.url, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                supportingContent = { if (r.note.isNotBlank()) Text(r.note) },
                trailingContent = { IconButton(onClick = { vm.deleteReport(r.id) }) { Icon(Icons.Filled.Delete, "Delete") } },
            )
        }
    }
}

@Composable
private fun LogTab(vm: AdminViewModel) {
    val list by vm.log.collectAsStateWithLifecycle()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    LazyColumn(Modifier.fillMaxSize()) {
        items(list) { e -> ListItem(headlineContent = { Text("${e.action}: ${e.target}") }, supportingContent = { Text(fmt.format(Date(e.ts))) }) }
    }
}

@Composable
private fun F(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun Sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

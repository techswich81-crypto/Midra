package com.gugugaga.mediaplatform.ui.browser

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.gugugaga.mediaplatform.browser.TabManager
import com.gugugaga.mediaplatform.util.Util

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabSwitcherScreen(
    manager: TabManager,
    onBack: () -> Unit,
    onOpenTab: (Long) -> Unit,
    onNewTab: () -> Unit,
    onNewIncognito: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tabs (${manager.tabs.size})") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    TextButton(onClick = onNewIncognito) { Text("Incognito") }
                    IconButton(onClick = { manager.closeAll() }) { Icon(Icons.Filled.DeleteSweep, "Close all") }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewTab) { Icon(Icons.Filled.Add, "New tab") }
        },
    ) { pad ->
        if (manager.tabs.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Koi tab khula nahi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(pad).fillMaxSize(),
            ) {
                items(manager.tabs.toList(), key = { it.id }) { t ->
                    Card(Modifier.fillMaxWidth().clickable { onOpenTab(t.id) }) {
                        Column {
                            Row(Modifier.padding(start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (if (t.incognito) "[Incog] " else "") + (if (t.pinned) "[Pin] " else "") + t.title.ifBlank { Util.hostOf(t.url) },
                                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelLarge,
                                )
                                IconButton(onClick = { manager.closeTab(t.id) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.Close, "Close tab") }
                            }
                            Box(Modifier.fillMaxWidth().height(120.dp).clip(MaterialTheme.shapes.small), contentAlignment = Alignment.Center) {
                                val bmp = t.thumbnail
                                if (bmp != null) {
                                    Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
                                } else {
                                    AsyncImage(model = Util.faviconUrl(t.url), contentDescription = null, modifier = Modifier.size(48.dp))
                                }
                            }
                            TextButton(onClick = { manager.togglePin(t) }) { Text(if (t.pinned) "Unpin" else "Pin") }
                        }
                    }
                }
            }
        }
    }
}

package com.gugugaga.mediaplatform.ui.extras

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gugugaga.mediaplatform.data.AppPrefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

// ------------------------------------------------------------------ Downloads (system DownloadManager)

data class DownloadRow(val id: Long, val title: String, val status: Int, val done: Long, val total: Long, val mime: String)

private fun queryDownloads(ctx: Context, ids: List<Long>): List<DownloadRow> {
    if (ids.isEmpty()) return emptyList()
    val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val out = ArrayList<DownloadRow>()
    runCatching {
        dm.query(DownloadManager.Query().setFilterById(*ids.toLongArray())).use { c ->
            while (c.moveToNext()) {
                out.add(
                    DownloadRow(
                        id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)),
                        title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)).orEmpty(),
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                        total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                        mime = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)).orEmpty(),
                    ),
                )
            }
        }
    }
    return out
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(prefs: AppPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var rows by remember { mutableStateOf<List<DownloadRow>>(emptyList()) }
    LaunchedEffect(Unit) {
        while (true) {
            rows = queryDownloads(ctx, prefs.downloadIds())
            delay(1_500)
        }
    }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Downloads") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(
                "System DownloadManager use hota hai: pause/resume app se nahi ho sakta (Android API me nahi hai).",
                Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Koi download nahi") }
            } else {
                LazyColumn {
                    items(rows, key = { it.id }) { r ->
                        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                        ListItem(
                            headlineContent = { Text(r.title.ifBlank { "File" }, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = {
                                Column {
                                    Text(
                                        when (r.status) {
                                            DownloadManager.STATUS_SUCCESSFUL -> "Complete"
                                            DownloadManager.STATUS_FAILED -> "Fail"
                                            DownloadManager.STATUS_PAUSED -> "Paused (network ka wait)"
                                            DownloadManager.STATUS_PENDING -> "Pending"
                                            else -> "Downloading"
                                        } + if (r.total > 0) " · ${r.total / 1024} KB" else "",
                                    )
                                    if (r.status == DownloadManager.STATUS_RUNNING && r.total > 0) {
                                        LinearProgressIndicator(progress = { (r.done.toFloat() / r.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                                    }
                                }
                            },
                            trailingContent = {
                                IconButton(onClick = { runCatching { dm.remove(r.id) }; rows = rows.filter { it.id != r.id } }) {
                                    Icon(Icons.Filled.Delete, "Delete")
                                }
                            },
                            modifier = Modifier.clickable(enabled = r.status == DownloadManager.STATUS_SUCCESSFUL) {
                                runCatching {
                                    val uri = dm.getUriForDownloadedFile(r.id)
                                    ctx.startActivity(
                                        Intent(Intent.ACTION_VIEW).setDataAndType(uri, r.mime.ifBlank { "*/*" })
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
                                    )
                                }.onFailure { Toast.makeText(ctx, "Koi app nahi mili", Toast.LENGTH_SHORT).show() }
                            },
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Site permissions

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SitePermissionsScreen(prefs: AppPrefs, onBack: () -> Unit) {
    var list by remember { mutableStateOf(prefs.allowedPerms()) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Site permissions") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(
                "Yahan wahi sites dikhti hain jinhe aapne 'Hamesha' allow kiya (camera/mic). Hatane par site dobara poochegi.",
                Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall,
            )
            if (list.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Koi saved permission nahi") }
            else LazyColumn {
                items(list, key = { it }) { e ->
                    ListItem(
                        headlineContent = { Text(e.substringBefore(':')) },
                        supportingContent = { Text(e.substringAfter(':')) },
                        trailingContent = { IconButton(onClick = { prefs.removeAllowedPerm(e); list = prefs.allowedPerms() }) { Icon(Icons.Filled.Delete, "Remove") } },
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Privacy policy (template)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("Privacy & Terms") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Privacy policy (template)", style = MaterialTheme.typography.titleMedium)
            Text(
                "• Is app me account/login nahi hai. Cart, My Tabs, Favorites, History, Bookmarks sirf aapke phone me save hote hain.\n" +
                    "• 'Aapke dekhe hue pages' search index (title, headings, shuru ka text) sirf is phone par rehta hai, kahin upload nahi hota. Settings me band/clear kar sakte hain.\n" +
                    "• App Firebase se websites ki list padhta hai. Kisi site ko kholne par us site ka counter +1 hota hai (anonymous, bina device ID ke).\n" +
                    "• 'Report this site' me jo URL/note aap bhejte hain wo admin ko dikhta hai.\n" +
                    "• Websites app ke andar khulti hain; unka apna content aur privacy policy un sites ki hoti hai. Cookies WebView me save hoti hain; Settings se clear kar sakte hain.\n" +
                    "• Camera/mic/location sirf tab use hota hai jab koi site maange aur aap allow karein.\n" +
                    "• Notifications opt-in hain (Settings).",
            )
            Text("Terms (template)", style = MaterialTheme.typography.titleMedium)
            Text(
                "• App sirf un websites ke liye hai jinka content dekhne/link karne ka haq ho.\n" +
                    "• Kisi site ka content/UI aapatti par hatane ke liye 'Report this site' use karein; admin site suspend kar sakta hai.\n" +
                    "• Ad-blocking 100% nahi hai aur kuch sites par site toot sakti hai; per-site mode Off kar sakte hain.",
            )
            Text(
                "Dhyan: ye ek template hai, legal advice nahi. Public release se pehle apne naam/contact ke saath kisi se review karwa lo.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
            )
        }
    }
}

// ------------------------------------------------------------------ Onboarding

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pages = listOf(
        "Websites app ke andar" to "Admin ki daali hui websites browser/Google par redirect hue bina yahin khulti hain. Multi-tab, find in page, desktop mode sab hai.",
        "Cart, My Tabs, Search" to "Apne links save karo (sirf aapke phone me). Search me admin sites, aapke dekhe pages, cart aur history sab milte hain.",
        "Ad-block aur Privacy" to "Ads/trackers block hote hain, tracking params hat jaate hain. Koi site toote to menu se ad-block mode badlo ya report karo.",
    )
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            HorizontalPager(state, Modifier.weight(1f)) { i ->
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(pages[i].first, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                    Text(pages[i].second, Modifier.padding(top = 16.dp), textAlign = TextAlign.Center)
                }
            }
            Text("${state.currentPage + 1} / ${pages.size}")
            Column(Modifier.padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (state.currentPage < pages.lastIndex) {
                    Button(onClick = { scope.launch { state.animateScrollToPage(state.currentPage + 1) } }) { Text("Next") }
                    TextButton(onClick = onDone) { Text("Skip") }
                } else {
                    Button(onClick = onDone) { Text("Shuru karo") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ App lock overlay

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Surface(Modifier.fillMaxSize().clickable(enabled = false) {}) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("App locked", style = MaterialTheme.typography.headlineSmall)
            Button(onClick = onUnlock, modifier = Modifier.padding(top = 16.dp)) { Text("Unlock") }
        }
    }
}

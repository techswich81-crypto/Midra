package com.gugugaga.mediaplatform.ui.home

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.gugugaga.mediaplatform.data.local.SiteEntity
import com.gugugaga.mediaplatform.util.Util
import com.gugugaga.mediaplatform.util.openCustomTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpen: (url: String, title: String, siteId: String) -> Unit,
    onSearch: () -> Unit,
    tabCount: Int,
    onTabs: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val syncing by vm.syncing.collectAsStateWithLifecycle()
    val syncError by vm.syncError.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    var clipUrl by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        runCatching {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            clipUrl = Util.smartUrl(t)
        }
    }

    val openSite: (SiteEntity) -> Unit = { s ->
        vm.onOpen(s)
        if (s.browsingMode.equals("customtab", true)) com.gugugaga.mediaplatform.util.Util.openCustomTab(ctx, s.url)
        else onOpen(s.url, s.name, s.id)
    }
    val card: @Composable (SiteEntity) -> Unit = { s ->
        SiteCard(
            site = s,
            badge = when {
                s.isPinned -> "Pinned"
                s.id in ui.hotIds -> "Hot"
                s.id in ui.newIds -> "New"
                else -> null
            },
            isFav = s.id in ui.favoriteIds,
            onOpen = { openSite(s) },
            onFav = { vm.toggleFavorite(s.id, s.id in ui.favoriteIds) },
            onCart = { vm.addToCart(s) },
            onShare = { Util.share(ctx, "${s.name}\n${s.url}") },
        )
    }

    PullToRefreshBox(isRefreshing = syncing, onRefresh = { vm.refresh(true) }, modifier = Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            full {
                Column {
                    Text("MediaPlatform", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth().clickable { onSearch() },
                    ) {
                        Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Search, null)
                            Spacer(Modifier.size(12.dp))
                            Text("Search ya URL daalo", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            clipUrl?.let { u ->
                full {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Copied link app me kholein?\n$u", Modifier.weight(1f).padding(vertical = 8.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { onOpen(u, Util.hostOf(u), ""); clipUrl = null }) { Text("Open") }
                            TextButton(onClick = { clipUrl = null }) { Text("X") }
                        }
                    }
                }
            }
            vm.maintenance().takeIf { it.isNotBlank() }?.let { msg ->
                full {
                    Card(Modifier.fillMaxWidth()) {
                        Text("Maintenance: $msg", Modifier.padding(14.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            vm.announcement().takeIf { it.isNotBlank() }?.let { msg ->
                full {
                    Card(Modifier.fillMaxWidth()) {
                        Text(msg, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (tabCount > 0) {
                full {
                    Card(Modifier.fillMaxWidth().clickable { onTabs() }) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Khule tabs: $tabCount", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                            Text("Dekho", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            vm.lastOpened()?.let { (url, title) ->
                full {
                    Card(Modifier.fillMaxWidth().clickable { onOpen(url, title, "") }) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Jahan chhoda tha wahin se", style = MaterialTheme.typography.labelMedium)
                            Text(title.ifBlank { Util.hostOf(url) }, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
            }
            if (ui.categories.isNotEmpty()) {
                full {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected = ui.selected == null, onClick = { vm.selectCategory(null) }, label = { Text("All") }) }
                        items(ui.categories, key = { it.id }) { c ->
                            FilterChip(selected = ui.selected?.id == c.id, onClick = { vm.selectCategory(c) }, label = { Text(c.name) })
                        }
                    }
                }
            }
            if (ui.recent.isNotEmpty()) {
                full {
                    Column {
                        Text("Recently opened", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ui.recent, key = { it.id }) { h ->
                                AssistChip(onClick = { onOpen(h.url, h.title, "") }, label = { Text(h.title.take(24), maxLines = 1) })
                            }
                        }
                    }
                }
            }
            section("Favorites", ui.favorites) { }
            if (ui.favorites.isNotEmpty()) {
                full {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ui.favorites, key = { "fav_" + it.id }) { s ->
                            AssistChip(onClick = { openSite(s) }, label = { Text(s.name, maxLines = 1) })
                        }
                    }
                }
            }
            section("Pinned", ui.pinned, card)
            section("Hot", ui.hot, card)
            section("All websites", ui.others, card)

            syncError?.let { msg -> full { Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) } }
            if (ui.totalSites == 0 && !syncing) {
                full {
                    Column(Modifier.fillMaxWidth().padding(vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Abhi koi website nahi mili.", style = MaterialTheme.typography.titleMedium)
                        Text("Admin ne sites add ki hongi to yahan dikhengi.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.refresh(true) }) { Text("Retry") }
                    }
                }
            }
        }
    }
}

private fun LazyGridScope.full(content: @Composable () -> Unit) {
    item(span = { GridItemSpan(maxLineSpan) }) { content() }
}

private fun LazyGridScope.section(title: String, list: List<SiteEntity>, content: @Composable (SiteEntity) -> Unit) {
    if (list.isEmpty()) return
    if (title != "Favorites") {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp))
        }
        items(list, key = { it.id }) { content(it) }
    } else {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(title, style = MaterialTheme.typography.titleSmall)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SiteCard(
    site: SiteEntity,
    badge: String?,
    isFav: Boolean,
    onOpen: () -> Unit,
    onFav: () -> Unit,
    onCart: () -> Unit,
    onShare: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Box {
        ElevatedCard(Modifier.fillMaxWidth().combinedClickable(onClick = onOpen, onLongClick = { menu = true })) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        AsyncImage(
                            model = site.iconUrl.ifBlank { Util.faviconUrl(site.url) },
                            contentDescription = site.name,
                            modifier = Modifier.size(48.dp).padding(8.dp).clip(RoundedCornerShape(8.dp)),
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    if (badge != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when (badge) {
                                "Hot" -> MaterialTheme.colorScheme.errorContainer
                                "Pinned" -> MaterialTheme.colorScheme.tertiaryContainer
                                else -> MaterialTheme.colorScheme.primaryContainer
                            },
                        ) {
                            Text(badge, Modifier.padding(horizontal = 6.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(site.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (site.description.isNotBlank()) {
                    Text(site.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("Open") }, onClick = { menu = false; onOpen() })
            DropdownMenuItem(
                text = { Text(if (isFav) "Favorite hatao" else "Favorite") },
                leadingIcon = { Icon(if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder, null) },
                onClick = { menu = false; onFav() },
            )
            DropdownMenuItem(text = { Text("Add to Cart") }, onClick = { menu = false; onCart() })
            DropdownMenuItem(text = { Text("Share") }, onClick = { menu = false; onShare() })
        }
    }
}

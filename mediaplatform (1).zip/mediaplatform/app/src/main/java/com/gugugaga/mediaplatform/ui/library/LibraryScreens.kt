package com.gugugaga.mediaplatform.ui.library

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.gugugaga.mediaplatform.data.local.BookmarkEntity
import com.gugugaga.mediaplatform.data.local.CartItem
import com.gugugaga.mediaplatform.data.local.MyTabEntity
import com.gugugaga.mediaplatform.util.Util
import java.text.DateFormat
import java.util.Date

typealias OpenFn = (url: String, title: String, siteId: String) -> Unit

@Composable
private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun Empty(msg: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FolderChips(folders: List<String>, selected: String?, onSelect: (String?) -> Unit) {
    if (folders.isEmpty()) return
    LazyRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item { FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text("All") }) }
        items(folders) { f -> FilterChip(selected = selected == f, onClick = { onSelect(if (selected == f) null else f) }, label = { Text(f) }) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LinkRow(
    title: String,
    url: String,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    extra: String? = null,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {},
) {
    ListItem(
        headlineContent = { Text((if (selected) "✓ " else "") + title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(listOfNotNull(url, extra).joinToString("\n"), maxLines = 3, overflow = TextOverflow.Ellipsis) },
        leadingContent = {
            AsyncImage(
                model = Util.faviconUrl(url), contentDescription = null,
                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).semantics { contentDescription = "Site icon" },
            )
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                actions()
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete $title") }
            }
        },
        modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick),
    )
}

@Composable
private fun TextDialog(
    title: String,
    fields: List<Triple<String, String, Boolean>>, // label, initial, singleLine
    onDismiss: () -> Unit,
    onSave: (List<String>) -> String?, // returns error text or null when saved
) {
    val values = remember { fields.map { mutableStateOf(it.second) } }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                fields.forEachIndexed { i, f ->
                    OutlinedTextField(values[i].value, { values[i].value = it }, label = { Text(f.first) }, singleLine = f.third)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val err = onSave(values.map { it.value })
                if (err == null) onDismiss() else error = err
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ------------------------------------------------------------------ Cart

@Composable
fun CartScreen(onOpen: OpenFn, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.cart.collectAsStateWithLifecycle()
    var sortByName by remember { mutableStateOf(false) }
    var folder by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<CartItem?>(null) }
    var selected by remember { mutableStateOf(setOf<Long>()) }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (selected.isEmpty()) "Cart" else "${selected.size} selected", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp).weight(1f))
            if (selected.isNotEmpty()) {
                IconButton(onClick = { vm.removeCart(selected); selected = emptySet() }) { Icon(Icons.Filled.DeleteSweep, "Delete selected") }
                TextButton(onClick = { selected = emptySet() }) { Text("Cancel") }
            } else {
                FilterChip(selected = sortByName, onClick = { sortByName = !sortByName }, label = { Text(if (sortByName) "A-Z" else "Newest") }, modifier = Modifier.padding(end = 12.dp))
            }
        }
        val list = items
        when {
            list == null -> Loading()
            list.isEmpty() -> Empty("Cart khaali hai. Kisi bhi page par menu se 'Add to Cart' karo.")
            else -> {
                FolderChips(list.map { it.folder }.filter { it.isNotBlank() }.distinct(), folder) { folder = it }
                val shown = list.filter { folder == null || it.folder == folder }.let { l -> if (sortByName) l.sortedBy { it.title.lowercase() } else l }
                LazyColumn {
                    items(shown, key = { it.id }) { c ->
                        val off = c.offlinePath.isNotBlank()
                        val sel = c.id in selected
                        LinkRow(
                            title = c.title, url = c.url,
                            onClick = {
                                if (selected.isNotEmpty()) selected = if (sel) selected - c.id else selected + c.id
                                else onOpen(if (off) "file://" + c.offlinePath else c.url, c.title, "")
                            },
                            onDelete = { vm.removeCart(c.id) },
                            extra = listOfNotNull(if (off) "[Offline]" else null, c.folder.takeIf { it.isNotBlank() }?.let { "📁 $it" }, c.note.takeIf { it.isNotBlank() }).joinToString("  ").ifBlank { null },
                            selected = sel,
                            onLongClick = { selected = selected + c.id },
                            actions = { IconButton(onClick = { editing = c }) { Icon(Icons.Filled.Edit, "Edit note") } },
                        )
                    }
                }
            }
        }
    }
    editing?.let { c ->
        TextDialog(
            "Note / folder",
            listOf(Triple("Note", c.note, false), Triple("Folder (Watch later, Read later...)", c.folder, true)),
            onDismiss = { editing = null },
        ) { v -> vm.editCart(c, v[0], v[1]); null }
    }
}

// ------------------------------------------------------------------ My Tabs

@Composable
fun MyTabsScreen(onOpen: OpenFn, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.tabs.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<MyTabEntity?>(null) }
    var folder by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Title("My Tabs")
            val list = items
            when {
                list == null -> Loading()
                list.isEmpty() -> Empty("Apna koi bhi link daalo (+ button).")
                else -> {
                    FolderChips(list.map { it.folder }.filter { it.isNotBlank() }.distinct(), folder) { folder = it }
                    val shown = list.filter { folder == null || it.folder == folder }
                    LazyColumn {
                        itemsIndexed(shown, key = { _, t -> t.id }) { i, t ->
                            LinkRow(
                                title = t.name, url = t.url,
                                onClick = { onOpen(t.url, t.name, "") },
                                onDelete = { vm.removeTab(t.id) },
                                extra = t.folder.takeIf { it.isNotBlank() }?.let { "📁 $it" },
                                actions = {
                                    IconButton(onClick = { vm.moveTab(shown, i, true) }, enabled = i > 0) { Icon(Icons.Filled.KeyboardArrowUp, "Move up") }
                                    IconButton(onClick = { vm.moveTab(shown, i, false) }, enabled = i < shown.lastIndex) { Icon(Icons.Filled.KeyboardArrowDown, "Move down") }
                                    IconButton(onClick = { editing = t }) { Icon(Icons.Filled.Edit, "Edit") }
                                },
                            )
                        }
                    }
                }
            }
        }
        FloatingActionButton(onClick = { dialog = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Icon(Icons.Filled.Add, "Add tab")
        }
    }

    if (dialog) {
        TextDialog(
            "Naya tab",
            listOf(Triple("Naam (optional)", "", true), Triple("Link", "", true), Triple("Folder (optional)", "", true)),
            onDismiss = { dialog = false },
        ) { v -> if (vm.addTab(v[0], v[1], v[2])) null else "Valid link daalo" }
    }
    editing?.let { t ->
        TextDialog(
            "Tab edit",
            listOf(Triple("Naam", t.name, true), Triple("Link", t.url, true), Triple("Folder", t.folder, true)),
            onDismiss = { editing = null },
        ) { v -> if (vm.editTab(t, v[0], v[1], v[2])) null else "Valid link daalo" }
    }
}

// ------------------------------------------------------------------ History / Bookmarks

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(onOpen: OpenFn, onBack: () -> Unit, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.history.collectAsStateWithLifecycle()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    var confirm by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("History") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { IconButton(onClick = { confirm = true }) { Icon(Icons.Filled.DeleteSweep, "Clear all") } },
        )
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val list = items
            when {
                list == null -> Loading()
                list.isEmpty() -> Empty("History khaali hai.")
                else -> LazyColumn { items(list, key = { it.id }) { h -> LinkRow(h.title, h.url, { onOpen(h.url, h.title, "") }, { vm.removeHistory(h.id) }, fmt.format(Date(h.visitedAt))) } }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Poori history delete karein?") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirm = false }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksScreen(onOpen: OpenFn, onBack: () -> Unit, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.bookmarks.collectAsStateWithLifecycle()
    var folder by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<BookmarkEntity?>(null) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Bookmarks") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            val list = items
            when {
                list == null -> Loading()
                list.isEmpty() -> Empty("Koi bookmark nahi. Browser me bookmark icon dabao.")
                else -> {
                    FolderChips(list.map { it.folder }.filter { it.isNotBlank() }.distinct(), folder) { folder = it }
                    LazyColumn {
                        items(list.filter { folder == null || it.folder == folder }, key = { it.id }) { b ->
                            LinkRow(
                                b.title, b.url, { onOpen(b.url, b.title, "") }, { vm.removeBookmark(b.id) },
                                extra = b.folder.takeIf { it.isNotBlank() }?.let { "📁 $it" },
                                actions = { IconButton(onClick = { editing = b }) { Icon(Icons.Filled.Edit, "Edit") } },
                            )
                        }
                    }
                }
            }
        }
    }
    editing?.let { b ->
        TextDialog("Bookmark edit", listOf(Triple("Title", b.title, true), Triple("Folder", b.folder, true)), onDismiss = { editing = null }) { v ->
            vm.editBookmark(b, v[0], v[1]); null
        }
    }
}

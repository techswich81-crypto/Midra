package com.gugugaga.mediaplatform.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gugugaga.mediaplatform.data.local.BookmarkDao
import com.gugugaga.mediaplatform.data.local.BookmarkEntity
import com.gugugaga.mediaplatform.data.local.CartDao
import com.gugugaga.mediaplatform.data.local.CartItem
import com.gugugaga.mediaplatform.data.local.HistoryDao
import com.gugugaga.mediaplatform.data.local.MyTabDao
import com.gugugaga.mediaplatform.data.local.MyTabEntity
import com.gugugaga.mediaplatform.util.Util
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val cartDao: CartDao,
    private val tabDao: MyTabDao,
    private val historyDao: HistoryDao,
    private val bookmarkDao: BookmarkDao,
) : ViewModel() {
    private val keep = SharingStarted.WhileSubscribed(5_000)
    val cart = cartDao.observe().stateIn(viewModelScope, keep, null)
    val tabs = tabDao.observe().stateIn(viewModelScope, keep, null)
    val history = historyDao.observeAll().stateIn(viewModelScope, keep, null)
    val bookmarks = bookmarkDao.observe().stateIn(viewModelScope, keep, null)

    fun removeCart(id: Long) { viewModelScope.launch { cartDao.delete(id) } }
    fun removeCart(ids: Collection<Long>) { viewModelScope.launch { ids.forEach { cartDao.delete(it) } } }
    fun editCart(item: CartItem, note: String, folder: String) {
        viewModelScope.launch { cartDao.insert(item.copy(note = note.trim().take(300), folder = folder.trim().take(30))) }
    }

    fun removeTab(id: Long) { viewModelScope.launch { tabDao.delete(id) } }
    fun removeHistory(id: Long) { viewModelScope.launch { historyDao.delete(id) } }
    fun clearHistory() { viewModelScope.launch { historyDao.clear() } }
    fun removeBookmark(id: Long) { viewModelScope.launch { bookmarkDao.delete(id) } }
    fun editBookmark(b: BookmarkEntity, title: String, folder: String) {
        viewModelScope.launch { bookmarkDao.insert(b.copy(title = title.trim().ifBlank { b.title }, folder = folder.trim().take(30))) }
    }

    /** Returns false if the URL is not valid. */
    fun addTab(name: String, rawUrl: String, folder: String): Boolean {
        val url = Util.smartUrl(rawUrl) ?: return false
        viewModelScope.launch { tabDao.insert(MyTabEntity(name = name.ifBlank { Util.hostOf(url) }, url = url, folder = folder.trim().take(30))) }
        return true
    }

    fun editTab(t: MyTabEntity, name: String, rawUrl: String, folder: String): Boolean {
        val url = Util.smartUrl(rawUrl) ?: return false
        viewModelScope.launch { tabDao.insert(t.copy(name = name.ifBlank { Util.hostOf(url) }, url = url, folder = folder.trim().take(30))) }
        return true
    }

    /** Swap with neighbour inside the currently shown list and renumber positions 1..n. */
    fun moveTab(shown: List<MyTabEntity>, index: Int, up: Boolean) {
        val j = if (up) index - 1 else index + 1
        if (j < 0 || j >= shown.size) return
        val all = (tabs.value ?: return).toMutableList()
        val a = all.indexOfFirst { it.id == shown[index].id }
        val b = all.indexOfFirst { it.id == shown[j].id }
        if (a < 0 || b < 0) return
        val tmp = all[a]; all[a] = all[b]; all[b] = tmp
        viewModelScope.launch { all.forEachIndexed { i, t -> tabDao.insert(t.copy(position = i + 1)) } }
    }
}

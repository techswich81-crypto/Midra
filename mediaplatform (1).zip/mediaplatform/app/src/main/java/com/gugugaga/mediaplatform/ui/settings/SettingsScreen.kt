package com.gugugaga.mediaplatform.ui.settings

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.webkit.WebViewCompat
import com.gugugaga.mediaplatform.BuildConfig
import com.gugugaga.mediaplatform.ui.theme.accentColor

@Composable
fun SettingsScreen(
    onHistory: () -> Unit,
    onBookmarks: () -> Unit,
    onDownloads: () -> Unit,
    onPermissions: () -> Unit,
    onPrivacy: () -> Unit,
    onAdmin: () -> Unit,
    vm: SettingsViewModel = hiltViewModel(),
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsStateWithLifecycle()
    val accent by vm.accent.collectAsStateWithLifecycle()
    val dynamic by vm.dynamic.collectAsStateWithLifecycle()
    val days by vm.historyDays.collectAsStateWithLifecycle()
    val adMode by vm.adMode.collectAsStateWithLifecycle()
    val strip by vm.strip.collectAsStateWithLifecycle()
    val https by vm.https.collectAsStateWithLifecycle()
    val third by vm.thirdParty.collectAsStateWithLifecycle()
    val saver by vm.dataSaver.collectAsStateWithLifecycle()
    val learned by vm.learned.collectAsStateWithLifecycle()
    val cookieHide by vm.cookieHide.collectAsStateWithLifecycle()
    val lock by vm.appLock.collectAsStateWithLifecycle()
    val lang by vm.lang.collectAsStateWithLifecycle()
    val nAll by vm.notifAll.collectAsStateWithLifecycle()
    val nNews by vm.notifNews.collectAsStateWithLifecycle()
    val updated by vm.filtersUpdatedAt.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val upd by vm.update.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    var taps by remember { mutableIntStateOf(0) }
    var crash by remember { mutableStateOf<String?>(null) }
    var lastTap by remember { mutableLongStateOf(0L) }

    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.clearMessage() } }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> uri?.let(vm::export) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::import) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val webViewInfo = remember { runCatching { WebViewCompat.getCurrentWebViewPackage(ctx)?.versionName }.getOrNull() }
    val webViewOld = (webViewInfo?.substringBefore('.')?.toIntOrNull() ?: 999) < 100

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text("Settings", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))

            Section("Theme")
            listOf("system" to "System", "light" to "Light", "dark" to "Dark", "amoled" to "AMOLED black").forEach { (k, l) ->
                Choice(l, theme == k) { vm.setTheme(k) }
            }
            Toggle("Dynamic color (Android 12+)", dynamic, vm::setDynamic)
            if (!dynamic) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("blue", "green", "red", "purple", "orange").forEach { a ->
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(accentColor(a))
                                .border(if (accent == a) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                .clickable { vm.setAccent(a) },
                        )
                    }
                }
            }

            Section("Language")
            listOf("system" to "System", "en" to "English", "hi" to "हिन्दी").forEach { (k, l) ->
                Choice(l, lang == k) {
                    vm.setLang(k)
                    (ctx as? Activity)?.recreate()
                }
            }
            Text(
                "Dhyan: abhi sirf bottom navigation/shortcuts ka text translate hota hai; baaki screens ka text Hinglish hi hai (poora localization baaki).",
                Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Section("Ad-block")
            listOf("off" to "Off", "normal" to "Normal", "strict" to "Strict").forEach { (k, l) -> Choice(l, adMode == k) { vm.setAdMode(k) } }
            if (vm.killSwitchOn) Text("Admin ne ad-block abhi emergency OFF kiya hai.", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error)
            ListItem(
                headlineContent = { Text("Filters abhi update karo") },
                supportingContent = { Text("Updated: " + if (updated == 0L) "kabhi nahi" else DateUtils.getRelativeTimeSpanString(updated).toString()) },
                modifier = Modifier.clickable { vm.updateFilters() },
            )
            Text(
                "Limits: YouTube/Twitch jaise sites ke in-stream ads (same domain) aur site ke apne HTML me bane ads 100% block nahi ho sakte. " +
                    "Koi ad-blocker 100% nahi hota; site toote to us site par per-site mode Off karo ya Report bhejo.",
                Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Section("Privacy & data")
            Toggle("Tracking params hatao (utm_, fbclid...)", strip, vm::setStrip)
            Toggle("HTTPS upgrade (http -> https)", https, vm::setHttps)
            Toggle("Third-party cookies allow (login sites ke liye)", third, vm::setThirdParty)
            Toggle("Data saver (images load nahi honge)", saver, vm::setDataSaver)
            Toggle("Cookie-consent banners chhupao", cookieHide, vm::setCookieHide)
            Toggle("Dekhe hue pages ka search index (sirf is phone me)", learned, vm::setLearned)
            ListItem(headlineContent = { Text("Search index clear karo") }, modifier = Modifier.clickable { vm.clearLearned() })
            Text("Naye settings naye khule tabs par lagte hain.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall)

            Section("History auto-clear")
            listOf(0 to "Kabhi nahi", 7 to "7 din baad", 30 to "30 din baad").forEach { (d, l) -> Choice(l, days == d) { vm.setHistoryDays(d) } }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Section("Security")
            Toggle("App lock (fingerprint / screen lock)", lock, vm::setAppLock)

            Section("Notifications (opt-in)")
            Toggle("Announcements / new sites", nAll) { vm.setNotifAll(it); if (it) askNotifPermission() }
            Toggle("News", nNews) { vm.setNotifNews(it); if (it) askNotifPermission() }

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Section("Library")
            ListItem(headlineContent = { Text("History") }, modifier = Modifier.clickable(onClick = onHistory))
            ListItem(headlineContent = { Text("Bookmarks") }, modifier = Modifier.clickable(onClick = onBookmarks))
            ListItem(headlineContent = { Text("Downloads") }, modifier = Modifier.clickable(onClick = onDownloads))
            ListItem(headlineContent = { Text("Site permissions") }, modifier = Modifier.clickable(onClick = onPermissions))

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Section("Backup")
            ListItem(headlineContent = { Text("Cookies aur site data clear karo") }, modifier = Modifier.clickable { vm.clearCookies() })
            ListItem(
                headlineContent = { Text("Backup export (JSON)") },
                supportingContent = { Text("Cart, My Tabs, Bookmarks, Favorites") },
                modifier = Modifier.clickable { exportLauncher.launch("mediaplatform-backup.json") },
            )
            ListItem(
                headlineContent = { Text("Backup restore") },
                modifier = Modifier.clickable { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
            )

            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Section("About")
            ListItem(headlineContent = { Text("Privacy & Terms") }, modifier = Modifier.clickable(onClick = onPrivacy))
            ListItem(
                headlineContent = { Text("Last crash report") },
                supportingContent = { Text("App crash ho to yahan error milta hai (mujhe bhejne ke liye)") },
                modifier = Modifier.clickable { crash = vm.crashText().ifBlank { "Koi crash record nahi hai." } },
            )
            ListItem(headlineContent = { Text("Update check (GitHub)") }, modifier = Modifier.clickable { vm.checkUpdate() })
            ListItem(
                headlineContent = { Text("Version") },
                supportingContent = { Text(BuildConfig.VERSION_NAME) },
                modifier = Modifier.clickable {
                    val now = System.currentTimeMillis()
                    taps = if (now - lastTap < 1_500) taps + 1 else 1
                    lastTap = now
                    if (taps >= 7) { taps = 0; onAdmin() }
                },
            )
            ListItem(
                headlineContent = { Text("Android System WebView") },
                supportingContent = {
                    Text((webViewInfo ?: "unknown") + if (webViewOld) "\nBahut purana hai: Play Store se 'Android System WebView' update karo." else "")
                },
            )
        }
        SnackbarHost(snack)
    }

    crash?.let { text ->
        AlertDialog(
            onDismissRequest = { crash = null },
            title = { Text("Last crash") },
            text = { Text(text.take(3000), style = MaterialTheme.typography.bodySmall, modifier = Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = {
                TextButton(onClick = {
                    runCatching {
                        ctx.startActivity(
                            Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                }) { Text("Share") }
            },
            dismissButton = { TextButton(onClick = { vm.clearCrash(); crash = null }) { Text("Clear") } },
        )
    }

    upd?.let { u ->
        AlertDialog(
            onDismissRequest = { vm.update.value = null },
            title = { Text("Naya version: ${u.tag}") },
            text = { Text("GitHub release page par APK download kar sakte ho.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.update.value = null
                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { vm.update.value = null }) { Text("Baad me") } },
        )
    }
}

@Composable
private fun Section(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
private fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

package com.gugugaga.mediaplatform.ui.settings

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebStorage
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.messaging.FirebaseMessaging
import com.gugugaga.mediaplatform.BuildConfig
import com.gugugaga.mediaplatform.adblock.AdBlockUpdateWorker
import com.gugugaga.mediaplatform.data.AppPrefs
import com.gugugaga.mediaplatform.data.BackupManager
import com.gugugaga.mediaplatform.data.local.LearnedDao
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.inject.Inject

data class UpdateInfo(val tag: String, val url: String)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val app: Context,
    val prefs: AppPrefs,
    private val backup: BackupManager,
    private val learnedDao: LearnedDao,
) : ViewModel() {
    val theme: StateFlow<String> = prefs.themeMode
    val accent: StateFlow<String> = prefs.accentFlow
    val dynamic: StateFlow<Boolean> = prefs.dynamicFlow
    val historyDays = MutableStateFlow(prefs.historyAutoClearDays)
    val adMode = MutableStateFlow(prefs.adblockMode)
    val strip = MutableStateFlow(prefs.stripTracking)
    val https = MutableStateFlow(prefs.httpsUpgrade)
    val thirdParty = MutableStateFlow(prefs.thirdPartyCookies)
    val dataSaver = MutableStateFlow(prefs.dataSaver)
    val learned = MutableStateFlow(prefs.learnedIndex)
    val cookieHide = MutableStateFlow(prefs.hideCookieBanners)
    val appLock = MutableStateFlow(prefs.appLock)
    val lang = MutableStateFlow(prefs.lang)
    val notifAll = MutableStateFlow(prefs.notifAll)
    val notifNews = MutableStateFlow(prefs.notifNews)
    val filtersUpdatedAt = MutableStateFlow(prefs.adblockUpdatedAt)
    val message = MutableStateFlow<String?>(null)
    val update = MutableStateFlow<UpdateInfo?>(null)

    val killSwitchOn: Boolean get() = prefs.adblockKill

    fun setTheme(m: String) = prefs.setTheme(m)
    fun setAccent(a: String) = prefs.setAccent(a)
    fun setDynamic(v: Boolean) = prefs.setDynamic(v)
    fun setHistoryDays(d: Int) { prefs.historyAutoClearDays = d; historyDays.value = d }
    fun setAdMode(m: String) { prefs.adblockMode = m; adMode.value = m }
    fun setStrip(v: Boolean) { prefs.stripTracking = v; strip.value = v }
    fun setHttps(v: Boolean) { prefs.httpsUpgrade = v; https.value = v }
    fun setThirdParty(v: Boolean) { prefs.thirdPartyCookies = v; thirdParty.value = v }
    fun setDataSaver(v: Boolean) { prefs.dataSaver = v; dataSaver.value = v }
    fun setAppLock(v: Boolean) { prefs.appLock = v; appLock.value = v }
    fun setLang(l: String) { prefs.lang = l; lang.value = l }

    fun setCookieHide(v: Boolean) { prefs.hideCookieBanners = v; cookieHide.value = v }
    fun setLearned(v: Boolean) { prefs.learnedIndex = v; learned.value = v }
    fun clearLearned() { viewModelScope.launch { learnedDao.clear(); message.value = "Dekhe hue pages ka index clear ho gaya" } }

    fun setNotifAll(v: Boolean) {
        prefs.notifAll = v; notifAll.value = v
        topic("all", v)
    }

    fun setNotifNews(v: Boolean) {
        prefs.notifNews = v; notifNews.value = v
        topic("news", v)
    }

    private fun topic(name: String, on: Boolean) {
        runCatching {
            val m = FirebaseMessaging.getInstance()
            if (on) m.subscribeToTopic(name) else m.unsubscribeFromTopic(name)
        }
    }

    fun updateFilters() {
        WorkManager.getInstance(app).enqueue(OneTimeWorkRequestBuilder<AdBlockUpdateWorker>().build())
        message.value = "Filters update shuru"
        viewModelScope.launch {
            kotlinx.coroutines.delay(8_000)
            filtersUpdatedAt.value = prefs.adblockUpdatedAt
        }
    }

    fun clearCookies() {
        runCatching {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        }
        message.value = "Cookies aur site data clear ho gaya"
    }

    /** GitHub Releases (latest). Public repos only: private repo API token ke bina 404 deta hai. */
    fun checkUpdate() {
        val repo = BuildConfig.GITHUB_REPO
        if (repo.isBlank()) { message.value = "GITHUB_REPO set nahi (Actions me automatic set hota hai)"; return }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 10_000; c.readTimeout = 10_000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                try {
                    if (c.responseCode != 200) error("Release nahi mila (HTTP ${c.responseCode}). Repo private ho sakta hai.")
                    val o = JSONObject(c.inputStream.bufferedReader().readText())
                    val tag = o.optString("tag_name")
                    val url = o.optString("html_url")
                    if (isNewer(tag, BuildConfig.VERSION_NAME)) update.value = UpdateInfo(tag, url)
                    else message.value = "App up-to-date (${BuildConfig.VERSION_NAME})"
                } finally { c.disconnect() }
            }.onFailure { message.value = it.message ?: "Update check fail" }
        }
    }

    private fun isNewer(tag: String, cur: String): Boolean {
        fun parts(s: String) = s.trim().removePrefix("v").split('.').map { it.takeWhile(Char::isDigit).toIntOrNull() ?: 0 }
        val a = parts(tag); val b = parts(cur)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    fun export(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val json = backup.exportJson()
                app.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(json.toByteArray()) }
            }.onSuccess { message.value = "Backup save ho gaya" }
                .onFailure { message.value = "Backup fail: ${it.message}" }
        }
    }

    fun import(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val text = app.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
                backup.importJson(text)
            }.onSuccess { message.value = "$it items restore hue" }
                .onFailure { message.value = "Restore fail: ${it.message}" }
        }
    }

    fun crashText(): String = runCatching { java.io.File(app.filesDir, "last_crash.txt").readText() }.getOrDefault("")
    fun clearCrash() { runCatching { java.io.File(app.filesDir, "last_crash.txt").delete() } }

    fun clearMessage() { message.value = null }
}

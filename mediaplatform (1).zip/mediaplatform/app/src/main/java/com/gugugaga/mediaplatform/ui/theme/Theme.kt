package com.gugugaga.mediaplatform.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

fun accentColor(name: String): Color = when (name) {
    "green" -> Color(0xFF2E7D32)
    "red" -> Color(0xFFC62828)
    "purple" -> Color(0xFF6A1B9A)
    "orange" -> Color(0xFFEF6C00)
    else -> Color(0xFF3D5AFE)
}

/** mode: system | light | dark | amoled. Dynamic color (Android 12+) overrides the accent when ON. */
@Composable
fun MediaTheme(mode: String = "system", accent: String = "blue", dynamic: Boolean = true, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "light" -> false
        "dark", "amoled" -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val seed = accentColor(accent)
    var scheme: ColorScheme = when {
        dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = seed.copy(alpha = 1f).let { Color(it.red * 0.6f + 0.4f, it.green * 0.6f + 0.4f, it.blue * 0.6f + 0.4f) })
        else -> lightColorScheme(primary = seed)
    }
    if (mode == "amoled") scheme = scheme.copy(background = Color.Black, surface = Color.Black)
    MaterialTheme(colorScheme = scheme, content = content)
}

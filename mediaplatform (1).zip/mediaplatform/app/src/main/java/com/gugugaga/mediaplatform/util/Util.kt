package com.gugugaga.mediaplatform.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.gugugaga.mediaplatform.data.local.SiteEntity
import kotlin.math.ln
import kotlin.math.min

object Util {
    fun hostOf(url: String): String =
        runCatching { Uri.parse(url).host.orEmpty().removePrefix("www.") }.getOrDefault("")

    fun faviconUrl(url: String): String =
        "https://www.google.com/s2/favicons?domain=${hostOf(url)}&sz=128"

    /** Returns a loadable http(s) URL if input looks like a URL, else null. */
    fun smartUrl(input: String): String? {
        val t = input.trim()
        if (t.isEmpty() || t.contains(' ')) return null
        if (t.startsWith("http://", true) || t.startsWith("https://", true)) return t
        val dot = t.indexOf('.')
        return if (dot > 0 && dot < t.length - 1) "https://$t" else null
    }

    fun searchUrl(q: String): String = "https://www.google.com/search?q=" + Uri.encode(q)

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    fun share(ctx: Context, text: String) {
        runCatching {
            ctx.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null,
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    }
}

object Ranking {
    /** Hot status uses server time, never the phone clock alone. */
    fun effectiveHot(s: SiteEntity, nowServer: Long): Boolean =
        s.isHot && (s.hotUntil == 0L || nowServer < s.hotUntil)

    /** Admin score weighs 65%, capped activity score 35%. */
    fun score(s: SiteEntity): Double {
        val admin = s.priorityScore.coerceIn(0, 100).toDouble()
        val activity = min(100.0, ln(1.0 + s.clickCount.coerceAtLeast(0)) * 15.0)
        return 0.65 * admin + 0.35 * activity
    }

    fun sorted(list: List<SiteEntity>, nowServer: Long): List<SiteEntity> =
        list.sortedWith(
            compareByDescending<SiteEntity> { it.isPinned }
                .thenByDescending { effectiveHot(it, nowServer) }
                .thenByDescending { score(it) }
                .thenBy { it.rankOrder }
                .thenBy { it.name.lowercase() },
        )
}

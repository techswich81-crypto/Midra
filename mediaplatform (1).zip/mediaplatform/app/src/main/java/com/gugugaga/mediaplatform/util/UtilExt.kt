package com.gugugaga.mediaplatform.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent

fun Util.openCustomTab(ctx: Context, url: String) {
    runCatching {
        val i = CustomTabsIntent.Builder().build()
        i.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.launchUrl(ctx, Uri.parse(url))
    }
}
